---
type: "Summary"
description: "Manual"
doc_type: short
full_text: "sources/manual.md"
---

Installation knowledge.