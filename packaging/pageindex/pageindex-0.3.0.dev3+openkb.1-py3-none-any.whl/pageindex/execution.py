"""Caller-owned request execution for the OpenKB-maintained distribution."""

from contextlib import contextmanager
from contextvars import ContextVar

import litellm

_HOOKS = ContextVar("pageindex_execution", default=None)


@contextmanager
def execution_scope(sync, asynchronous, checkpoint=lambda: None, close=None):
    token = _HOOKS.set((sync, asynchronous, checkpoint, close))
    try:
        yield
    finally:
        _HOOKS.reset(token)


def checkpoint():
    hooks = _HOOKS.get()
    if hooks:
        hooks[2]()


def completion(**kwargs):
    hooks = _HOOKS.get()
    return hooks[0](**kwargs) if hooks else litellm.completion(**kwargs)


async def acompletion(**kwargs):
    hooks = _HOOKS.get()
    return await (hooks[1](**kwargs) if hooks else litellm.acompletion(**kwargs))


async def close():
    hooks = _HOOKS.get()
    if hooks and hooks[3]:
        await hooks[3]()
